 <?php 
 include 'conexao.php';
 include 'seguranca.php';


// Pesuisa do usuário logado
 
$sql = "SELECT * FROM usuario WHERE username_usuario = '".$_SESSION['username_usuario']."'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array( $result);


if(isset($_GET['submit'])){

	$nome_usuario=$_GET['nome_usuario'];
	$sexo_usuario=$_GET['nome_usuario'];
	$skype_usuario=$_GET['skype_usuario'];
	$ts_usuario=$_GET['ts_usuario']; 
	$discord_usuario=$_GET['discord_usuario'];
	$lol_usuario=$_GET['lol_usuario'];
	$over_usuario=$_GET['over_usuario'];
	$pubg_usuario=$_GET['pubg_usuario'];

$sqlUpdate = "UPDATE usuario SET nome_usuario = '$nome_usuario', sexo_usuario = '$sexo_usuario', skype_usuario ='$skype_usuario', ts_usuario = '$ts_usuario', discord_usuario = '$discord_usuario', lol_usuario = '$lol_usuario', over_usuario = '$over_usuario', pubg_usuario = '$pubg_usuario' WHERE username_usuario = '".$_SESSION['username_usuario']."' " ;

 $rsEdit = mysqli_query($conn, $sqlUpdate);
	if(mysqli_errno($conn)==0){
		echo "Dados alterados com sucesso!";
	}
	 else {
		 echo("Erro: ". mysqli_errno($conn));
		}
		mysqli_close($conn);
}



?>
<html>
	<head>
		<title>HiDuo! - Melhores Duplas </title>
		<meta charset="utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		
		<link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">

		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

		<script type="text/javascript" src="suporte.js"></script>
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		
		<link rel="shortcut icon" href="image/hiduo" type="image/x-icon">
		<link href="css/perfil.css" rel="stylesheet">
 		
	<body>
		<nav>
			<form>
					<ul class="nav nav-pills nav-fill nav-justified">
						<li class="nav-item"><a href="index.php" id="active" class="nav-link"><img src="image/hiduoicon.png" width="80"></a></li>
						<li class="nav-item"><a href="dupla.php" class="nav-link">Procurar Dupla</a></li>
						<li class="nav-item"><a href="rank.php" class="nav-link">Melhores Duplas</a></li>
						<li class="nav-item"><a href="suporte.php" class="nav-link">Suporte</a></li>
						<li class="nav-item"><a href="logout.php" class="nav-link">Sair</a></li>
					</ul>
			</form>
		</nav>
			
		</div>
		 <div class="container theme-showcase" role="main">
		<div class="col-md-9">
			<div id="conteudo">
			<h3><strong><p class="text-center">Alterar perfil</p></strong></h3>
			<div class="col-md-3">

aa

			</div>
			<div class="col-md-3">

aa

			</div>
			<div class="col-md-3">

aa

			</div>
			</div>

			</div>
		</div>	
	</body>
</html>