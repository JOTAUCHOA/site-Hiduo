<?php
// Desative essa variável para visualizar os erros -->
error_reporting(0);

include 'mensagem.php';
include 'conexao.php';

 // Se o botão de Cadastrar for clicado, ele pega as variáveis que estão nos campos preenchddos e envia ao BD -->

if(isset($_POST['submit'])){
$nome_usuario=$_POST['nome_usuario'];
$data =$_POST['ano']."-".$_POST['mes']."-".$_POST['dia'];
$idade_usuario=$data;
$email_usuario=$_POST['email_usuario'];
$username_usuario=$_POST['username_usuario'];
$sexo_usuario=$_POST['sexo_usuario'];
$senha_usuario=$_POST['senha_usuario'];
$skype_usuario=$_POST['skype_usuario'];
$ts_usuario=$_POST['ts_usuario'];
$discord_usuario=$_POST['discord_usuario'];
$lol_usuario=$_POST['lol_usuario'];
$icone_usuario=$_POST['icone_usuario'];
$estado_usuario=$_POST['estado_usuario'];

if(isset($_POST['nome_usuario']) && 
	isset($_POST['ano']) && 
	isset($_POST['mes']) &&
	isset($_POST['dia']) &&
	isset($_POST['email_usuario']) &&
	isset($_POST['username_usuario']) &&
	isset($_POST['sexo_usuario']) &&
	isset($_POST['senha_usuario']) &&
	isset($_POST['nome_usuario']) &&
	isset($_POST['skype_usuario']) &&
	isset($_POST['ts_usuario']) &&
	isset($_POST['discord_usuario']) &&
	isset($_POST['lol_usuario']) &&
	isset($_POST['icone_usuario']) &&
	isset($_POST['estado_usuario'])){

	// Query de Cadastro -->

$sqlCadastro = "INSERT INTO usuario (`nome_usuario`, `idade_usuario`, `email_usuario`, `username_usuario` , `sexo_usuario`, `senha_usuario` , `skype_usuario` , `ts_usuario`, `discord_usuario`, `lol_usuario`,`icone_usuario`,`estado_usuario`) VALUES ('$nome_usuario', '$idade_usuario', '$email_usuario', '$username_usuario', '$sexo_usuario', MD5('$senha_usuario') , '$skype_usuario', '$ts_usuario', '$discord_usuario', '$lol_usuario','$icone_usuario','$estado_usuario')";
 
$rs = mysqli_query($conn, $sqlCadastro);
	if(mysqli_errno($conn)==0){
		$msg = new Mensagem("Cadastro realizado com sucesso!"," <a href='login.php'> Clique aqui para iniciar sua sessão!</a>","success");
	}
	 else {
		 $msg = new Mensagem("Erro","Preencha os campos obrigatórios.","danger");
		}

} else{
		$msg = new Mensagem("Erro","Preencha todos os campos.","danger");
}

}

?>

<!DOCTYPE html>
<html>
<head>
	<title>HiDuo!</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">

	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="css/cadastro.css">

	<!-- Bootstrap -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">

	<!-- Fonte do Google -->
	<link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">

	<!-- Favicon -->
	<link rel="shortcut icon" href="hiduo2.png" type="image/x-icon">

	<!-- caixas do js -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<script type="text/javascript" src="js/jSonChange.js"></script>

	<style type="text/css" >
	.msg-erro{ color: red; }
	</style>

</head>
<body>
<div class="body">
		<img src="image/hiduo.png">
		<div class="content">
		<div>
			<form method="post" id="form-cadastro">
					<h1><label>CADASTRE-SE AGORA NO HIDUO!</label></h1>
					<!-- Aqui mostra as mensagens (Sucesso ou Erro)  -->
												<?php
		if(isset($msg)) $msg->mostrar();
		?>
					<div class="direita float-right">
						<label>TeamSpeak</label><br>
						<input type="text" id="ts" class="form-control" name="ts_usuario" placeholder="Seu TS"><br>
						<label>Skype</label><br>
						<input type="text" id="skype" class="form-control" name="skype_usuario" placeholder="Nome de usuário do Skype"><br>
						<label>League of Legends</label><br>
						<input type="text" id="lol" class="form-control" name="lol_usuario" placeholder="Nome de usuário do League of Legends" onChange="validarLOL()"><br>
						<span class='msg-erro msg-lol'>
						</span>
						<br>
						<label>Escolha Seu Ícone De Perfil *</label><br>
						<label>
							<img src="image/icon1.png" width="90px" height="90px">
							<input type="radio" name="icone_usuario" id="optionsRadios2" value="1" hidden="yes">
						</label>
						<label>
							<img src="image/icon2.png" width="90px" height="90px">
							<input type="radio" name="icone_usuario" id="optionsRadios2" value="2" hidden="yes">
						</label>
						<label>
							<img src="image/icon3.png" width="90px" height="90px">
							<input type="radio" name="icone_usuario" id="optionsRadios2" value="3" hidden="yes">
						</label>
						<label>
							<img src="image/icon4.png" width="90px" height="90px">
							<input type="radio" name="icone_usuario" id="optionsRadios2" value="4" hidden="yes">
						</label>
						<label>
							<img src="image/icon5.png" width="90px" height="90px">
							<input type="radio" name="icone_usuario" id="optionsRadios2" value="5" hidden="yes">
						</label>
						<label>
							<img src="image/icon6.png" width="90px" height="90px">
							<input type="radio" name="icone_usuario" id="optionsRadios2" value="6" hidden="yes">
						</label>
						<label>
							<img src="image/icon7.png" width="90px" height="90px">
							<input type="radio" name="icone_usuario" id="optionsRadios2" value="7" hidden="yes">
						</label>
						<label>
							<img src="image/icon8.png" width="90px" height="90px">
							<input type="radio" name="icone_usuario" id="optionsRadios2" value="8" hidden="yes">
						</label>
						<label>
							<img src="image/icon9.png" width="90px" height="90px">
							<input type="radio" name="icone_usuario" id="optionsRadios2" value="9" hidden="yes">
						</label>
						<label>
							<img src="image/icon0.png" width="90px" height="90px">
							<input type="radio" name="icone_usuario" id="optionsRadios2" value="0" hidden="yes">
						</label>
						
					</div>
					<div class="esquerda">
						<label for="nome">Nome e Sobrenome *</label><br>
						<input type="text" id="nome" class="form-control" name="nome_usuario" placeholder="Digite seu nome e Sobrenome" onclick="teste()"><br>
						<span class='msg-erro msg-nome'>
		       		    </span>
						<label for="username">Nome De Usuário *</label><br>
						<input type="text" id="username" class="form-control" name="username_usuario" placeholder="Digite um nome de usuário" onchange="validarUser()"><br>
						<span class='msg-erro msg-username'>
		       		    </span>
						<label for="dia">Data De Nascimento*</label><br>
						<select id="dia" name="dia" onchange="validarData()">
							<option disabled selected >Dia</option>
							<option value="01">01</option>
							<option value="02">02</option>
							<option value="03">03</option>
							<option value="04">04</option>
							<option value="05">05</option>
							<option value="06">06</option>
							<option value="07">07</option>
							<option value="08">08</option>
							<option value="09">09</option>
							<option value="10">10</option>
							<option value="11">11</option>
							<option value="12">12</option>
							<option value="13">13</option>
							<option value="14">14</option>
							<option value="15">15</option>
							<option value="16">16</option>
							<option value="17">17</option>
							<option value="18">18</option>
							<option value="19">19</option>
							<option value="20">20</option>
							<option value="21">21</option>
							<option value="22">22</option>
							<option value="23">23</option>
							<option value="24">24</option>
							<option value="25">25</option>
							<option value="26">26</option>
							<option value="27">27</option>
							<option value="28">28</option>
							<option value="29">29</option>
							<option value="30">30</option>
							<option value="31">31</option>
						</select>
						<select id="mes" name="mes">
							<option disabled selected>Mês</option>
							<option value="01">Janeiro</option>
							<option value="02">Fevereiro</option>
							<option value="03">Março</option>
							<option value="04">Abril</option>
							<option value="05">Maio</option>
							<option value="06">Junho</option>
							<option value="07">Julho</option>
							<option value="08">Agosto</option>
							<option value="09">Setembro</option>
							<option value="10">Outubro</option>
							<option value="11">Novembro</option>
							<option value="12">Dezembro</option>
						</select>
						<select id="ano" name="ano">
							<option disabled selected>Ano</option>
							<option value="2007">2007</option>
							<option value="2006">2006</option>
							<option value="2005">2005</option>
							<option value="2004">2004</option>
							<option value="2003">2003</option>
							<option value="2002">2002</option>
							<option value="2001">2001</option>
							<option value="2000">2000</option>
							<option value="1999">1999</option>
							<option value="1998">1998</option>
							<option value="1997">1997</option>
							<option value="1996">1996</option>
							<option value="1995">1995</option>
							<option value="1994">1994</option>
							<option value="1993">1993</option>
							<option value="1992">1992</option>
							<option value="1991">1991</option>
							<option value="1990">1990</option>
							<option value="1989">1989</option>
							<option value="1988">1988</option>
							<option value="1987">1987</option>
							<option value="1986">1986</option>
							<option value="1985">1985</option>
							<option value="1984">1984</option>
							<option value="1983">1983</option>
							<option value="1982">1982</option>
							<option value="1981">1981</option>
							<option value="1980">1980</option>							
						</select><br>
						<span class='msg-erro msg-data'>
						</span>
						<label for="sexo">Sexo *</label><br>
						<select id="sexo" name="sexo_usuario" onchange="validarSexo()">
							<option disabled selected value="">Sexo</option>
							<option value="M">Masculino</option>
							<option value="F">Feminino</option>
							<option value="O">Outro</option>							
						</select><br>
						<span class='msg-erro msg-sexo'>
						</span>
						<label for="estado">Estado *</label><br>
						<select id="estado" name="estado_usuario" onchange="validarEstado()">
							<option disabled selected value="">Estado</option>
							<option value="AC">Acre</option>
							<option value="AL">Alagoas</option>
							<option value="AP">Amapá</option>
							<option value="AM">Amazonas</option>
							<option value="BA">Bahia</option>
							<option value="CE">Ceará</option>
							<option value="DF">Distrito Federal</option>
							<option value="ES">Espírito Santo</option>
							<option value="GO">Goiás</option>
							<option value="MA">Maranhão</option>
							<option value="MT">Mato Grosso</option>
							<option value="MS">Mato Grosso do Sul</option>
							<option value="MG">Minas Gerais</option>
							<option value="PA">Pará</option>
							<option value="PB">Paraíba</option>
							<option value="PR">Paraná</option>
							<option value="PE">Pernambuco</option>
							<option value="PI">Piauí</option>
							<option value="RJ">Rio de Janeiro</option>
							<option value="RN">Rio Grande do Norte</option>
							<option value="RS">Rio Grande do Sul</option>
							<option value="RO">Rondônia</option>
							<option value="RR">Roraima</option>
							<option value="SC">Santa Catarina</option>
							<option value="SP">São Paulo</option>
							<option value="SE">Sergipe</option>
							<option value="TO">Tocantins</option>
						</select><br>
							<span class='msg-erro msg-estado'>
							</span>
						<label>E-mail *</label><br>
						<input type="email" id="email" class="form-control" name="email_usuario" placeholder="Digite seu e-mail" onchange="validarEmail()"><br>
						<span class='msg-erro msg-email'>
		       		    </span>
						<label>Senha *</label><br>
						<input type="password" id="senha" class="form-control" name="senha_usuario" placeholder="Digite sua senha"onChange="validarSenha()"><br>
						<span class='msg-erro msg-senha'>
		       		    </span>
						<label>Confirmação de Senha *</label><br>
						<input type="password" id="senha2" class="form-control" placeholder="Confirme sua senha" onchange="validarSenha2()"><br>
						<span class='msg-erro msg-senha2'>
		       		    </span><br>
						<label>Discord</label><br>
						<input type="text" id="discord" class="form-control" name="discord_usuario" placeholder="Nome de usuário no Discord"><br>
					</div>
					<div class="botoes">
						<input type="submit" name="submit" class="btn btn-primary" value="Cadastrar">
						<a href="login.php"><input type="button" class="btn btn-danger" value="Cancelar">
					</div>
				</form>
		</div>			
		</div>								
</body>
</html>