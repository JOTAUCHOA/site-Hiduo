<?php 
// Informacoes do banco e server
$servername = "localhost";
$username="root";
$password="";
$db="hiduo";

// Conexao com banco de dados

try{
$conn = mysqli_connect($servername, $username,$password,$db);
}catch(MySQLi_Sql_Exception $ex){
	echo "Verifique a conexao com o banco!";
}

?>