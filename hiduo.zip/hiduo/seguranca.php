<?php  
	session_start();
	if(!isset($_SESSION['username_usuario']) && !isset($_SESSION['senha_usuario'])){
		header("Location: login.php?erro=2");
	}
		
 ?>	
