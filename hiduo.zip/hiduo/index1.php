<?php 
	include  'conexao.php';
	include  'seguranca.php';
	include 'mensagem.php';

	$sql = "SELECT * FROM usuario WHERE username_usuario = '".$_SESSION['username_usuario']."'";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_array($result);



	if(isset($_GET['registraDuo'])){

	$session_user = $row['id_usuario'];
	$usuario_soli = $_GET['usuario_soli'];	
	$id_soli = $_GET['id_soli'];	
	$jogo = $_GET['jogo'];

	// Inseri na table DUO

	$sqlDupla = "INSERT INTO `duo` (`id_duo`, `user1_duo`, `user2_duo`, `jogo_duo`) VALUES (NULL, '$session_user', '$usuario_soli','$jogo')"; 
	$rsInsert = mysqli_query($conn, $sqlDupla);

	// Inseri na tabela usuario o ID do cara selecionado

	$sqlDuo ="UPDATE `usuario` SET `idDuo_usuario` = '$usuario_soli' WHERE `usuario`.`id_usuario` = $session_user;";
	$rsInsert = mysqli_query($conn, $sqlDuo);

	// Inseri na tabela do cara

		$sqlDuo1 ="UPDATE `usuario` SET `idDuo_usuario` = $session_user WHERE `usuario`.`id_usuario` = $id_soli;";
		$rsInsert = mysqli_query($conn, $sqlDuo1);

	// Deletar solicitação de duo	

		$sqlApagarSoli ="DELETE FROM `solicitacoes` WHERE id_soli = $id_soli";
		$rsDelete = mysqli_query($conn, $sqlApagarSoli);

	if(mysqli_errno($conn)==0){
		$msg = new Mensagem("Dupla formada!","Atualize a pagina para iniciar o Duo!","success");
	}
	 else {
		 $msg = new Mensagem("Erro","Temos um erro :( ". mysqli_error($conn),"danger");
	}
}

	if(isset($_GET['excluiSolicitacao'])){

	$id_soli = $_GET['id_soli'];

		$sqlApagarSoli ="DELETE FROM `solicitacoes` WHERE id_soli = $id_soli";
		$rsDelete = mysqli_query($conn, $sqlApagarSoli);

	if(mysqli_errno($conn)==0){
		$msg = new Mensagem("Solicitação excluida!","","success");
	}
	 else {
		 $msg = new Mensagem("Erro","Temos um erro :( ". mysqli_error($conn),"danger");
	}		

	}


	$sexo = $row['sexo_usuario'];
	if ($sexo=='G') {
			$sexo="Outro";
		}
	if ($sexo=='M') {
			$sexo="Masculino";
		}
	if ($sexo=='F') {
			$sexo="Feminino";
		}	
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Bem-vindo <?php echo $row['username_usuario'] ?>!</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">

	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="css/index.css">

	<!-- Bootstrap -->	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
	
	<!-- Fonte do Google -->
	<link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">

	<!-- Favicon -->
	<link rel="shortcut icon" href="hiduo2.png" type="image/x-icon">

	<!-- JavaScript Troca de imagens -->
	<script type="text/javascript">
		var i =0;
		var images =[];
		var links = [];
		var time = 6000;

		images[0] = 'image/lol2.jpg';
		images[1] = 'image/fort1.jpg';
		images[2] = 'image/outros.jpg';

		links[0] = 'index.php';
		links[1] = 'dupla.php';
		links[2] = 'suporte.php';
	


		function trocaImg(){
			document.getElementById("troca").src = images[i];
			document.getElementById("linkdog").href = links[i];			
			if (images[i]==images[0]) {
				document.getElementById("radlol").checked = true;
			}
			if (images[i]==images[1]) {
				document.getElementById("radow").checked = true;
			}
			if (images[i]==images[2]) {
				document.getElementById("radpubg").checked = true;
			}
			if (i<images.length - 1) {
				i++;
			}else{
				i=0;
			}
			
			setTimeout("trocaImg()",time);
		}

		function radlol(){
			i=0;
			document.getElementById("troca").src = images[i];
			document.getElementById("linkdog").href = links[i];	
		}
		function radow(){
			i=1;
			document.getElementById("troca").src = images[i];
			document.getElementById("linkdog").href = links[i];	
		}
		function radpubg(){
			i=2;
			document.getElementById("troca").src = images[i];
			document.getElementById("linkdog").href = links[i];	
		}
	</script>

	<!-- JavaScript Alterar/Excluir perfil-->
	<script type="text/javascript">
		// Calcular Idade
		var age;
		function calculate_age () {
			var now = new Date();
			var r = document.getElementById("lbldata").innerHTML;
			var replace = r.replace("-",",");
			var data = new Date(r);
			age = now - data;
			age = Math.floor(age/1000/60/60/24/365.25);
			document.getElementById("lbldata").innerHTML= "<img src='image/ageicon.png' width='20'> "+age+" anos";
			document.getElementById("lbldata").hidden = false;
			}


	</script>

</head>
<body onload="trocaImg(),calculate_age()">
	<div class="body">
			<nav>
			<form>
					<ul class="nav nav-pills nav-fill nav-justified">
						<li class="nav-item"><a href="index.php" id="active" class="nav-link"><img src="image/hiduoicon.png" width="80"></a></li>
						<li class="nav-item"><a href="dupla.php" class="nav-link">Procurar Dupla</a></li>
						<li class="nav-item"><a href="rank.php" class="nav-link">Melhores Duplas</a></li>
						<li class="nav-item"><a href="suporte.php" class="nav-link">Suporte</a></li>
						<li class="nav-item"><a href="logout.php" class="nav-link">Sair</a></li>
					</ul>
			</form>
		</nav>
		<div class="content">
			<div class="direita float-right">
				<a id="linkdog"><img id="troca"></a>
				<div class="custom-control custom-radio custom-control-inline float-right" >
  					<input type="radio" id="radpubg" name="radios" class="custom-control-input" onclick="radpubg()">
 					<label class="custom-control-label" for="radpubg" ></label>
				</div>
				<div class="custom-control custom-radio custom-control-inline float-right">
  					<input type="radio" id="radow" name="radios" class="custom-control-input" onclick="radow()">
 					<label class="custom-control-label" for="radow"></label>
				</div>
  				<div class="custom-control custom-radio custom-control-inline float-right">
					<input type="radio" id="radlol" name="radios" class="custom-control-input" onclick="radlol()">
					<label class="custom-control-label" for="radlol"></label>
				</div>
<!--  Mostra as solicitacoes de Duo  -->				
				<div class="inferior">
					<div class="duo">
						<p> Solicitação recebidas </p>
						<div class="panel panel-default">
	    					<div class="panel-body">
    							<table class="table table-hover">

    								<tr>
    									<th style="display:none;">id_usuario</th>
    									<th style="display:none;">name_usuario</th>
    									<th></th>    									
    									<th></th>    									
    									<th></th>    									
										<th> Usuário </th>						
										<th> Jogo </th>
										<th> Ranqueamento </th>												
										<th> Data </th>						
										<th> Aceitar </th>
    								</tr>	
    								<form action="index.php" method="GET"> 
					<?php
						//error_reporting(0);
						// Busca todos campos e registros da tabela "Usuarios";
						$session_user = $row['id_usuario'];

					//	$sqlStart = "SELECT * FROM solicitacoes WHERE player2_soli = $session_user"; 
	
						// Inner Join try >
						$sqlStart = "SELECT soli.jogo_soli,soli.id_soli,soli.data_soli, usu.id_usuario,usu.username_usuario,usu.elo_usuario,jogo.nome_jogo from solicitacoes as soli inner join usuario as usu on soli.solicitante_soli = usu.id_usuario inner join jogo as jogo on soli.jogo_soli = jogo.id_jogo WHERE solicitado_soli = $session_user";
													 	
						$rs = mysqli_query($conn, $sqlStart);
    		   			while ($solicitacoes = mysqli_fetch_array($rs)){
							$id_soli         = $solicitacoes["id_soli"];		
							$usuario_soli    = $solicitacoes["id_usuario"];		
							$player1         = $solicitacoes["username_usuario"];
							$jogo 	         = $solicitacoes["nome_jogo"];
							$outrojogo 	     = $solicitacoes["jogo_soli"];
							$elo   	         = $solicitacoes["elo_usuario"];
							$data 	         = $solicitacoes["data_soli"];
						
    		   			echo "<tr>";
						echo "<td><input type='hidden' name='id_soli' value='$id_soli'> </td>";
						echo "<td><input type='hidden' name='jogo' value='$outrojogo'> </td>";
						echo "<td><input type='hidden' name='usuario_soli' value='$usuario_soli'> </td>";
						echo "<td>$player1</td>";
						echo "<td>$jogo</td>";
						echo "<td>$elo</td>";
						echo "<td>$data</td>";
						echo "<td>";
						echo " <button class='btn btn-danger' type='submit' name='excluiSolicitacao' > <img src='image/multiply.png'>  </button>";
						echo " <button class='btn btn-success' type='submit' name='registraDuo'> <img src='image/checked.png'>  </button>";
						echo "</td>";
						echo "</tr>";
								} 														
						?>					
    							</table>
    						</form>
    							<?php
		if(isset($msg)) $msg->mostrar();
		?>
    						</div>
    					</div>
					
				</div>
<!--  Mostra o seu Duo atual  -->				
					<div class="minhadupla">
						<p> Minhas duplas </p>
							<div class="panel panel-default">
	    					<div class="panel-body">
    							<table class="table table-hover">
    								<tr>
    									<th style="display:none;">id_usuario</th>
    									<th style="display:none;">name_usuario</th>     	
										<th> Usuário </th>						
										<th> Jogo </th>
										<th> Ranqueamento </th>												
										<th> Data </th>						
										<th> Iniciar </th>
    								</tr>	
    								<form action="chatter/index.php" method="POST"> 
					<?php
						//error_reporting(0);
						// Busca todos campos e registros da tabela "Usuarios";
						$user_chat = $row['username_usuario'];	
						$idDuo_usuario = $row['idDuo_usuario'];

						//$sqlSolicitacoes = "SELECT * FROM usuario WHERE id_usuario = $idDuo_usuario"; 
						//$rs = mysqli_query($conn, $sqlSolicitacoes);


						$sqlMostraDuos = "SELECT duo.jogo_duo,duo.data_duo, usu.id_usuario,usu.username_usuario,usu.elo_usuario,jogo.nome_jogo from duo as duo inner join usuario as usu on duo.user2_duo = usu.id_usuario inner join jogo as jogo on duo.jogo_duo = jogo.id_jogo WHERE user1_duo = $session_user";
													 	
						$rs = mysqli_query($conn, $sqlMostraDuos);	

    		   			while ($duo = mysqli_fetch_array($rs)){
						//	$id_duo 	       = $duo["id_usuario"];		
							$usuario	   	   = $duo["username_usuario"];
							$jogoduo 	       = $duo["nome_jogo"];
							$elo	  		   = $duo["elo_usuario"];
							$data 	           = $duo["data_duo"];
						
    		   			echo "<tr>";
					//	echo "<td><input type='hidden' name='nome_chat' value=$user_chat></td>";
					//	echo "<td><input type='hidden' name='id_duo' value='$id_duo'></td>";
					//	echo "<td><input type='hidden' name='user_duo' value='$user_duo'></td>";
						echo "<td>$usuario</td>";
						echo "<td>$jogoduo</td>";
						echo "<td>$elo</td>";
						echo "<td>$data</td>";
						echo "<td>";
						echo "<button class='btn btn-success' type='submit' name='iniciaDuo'> Iniciar Duo </button>";
						echo "</td>";
						echo "</tr>";															
								} 														
						?>		
    							</table>
    						</form>
    							<?php
		if(isset($msg)) $msg->mostrar();
		?>
    						</div>
    					</div>
					
					</div>
				</div>
			</div >
			<aside class="perfil">
				<img id="icon" src="<?php echo 'image/icon'.$row['icone_usuario'].'.png'; ?>" width="150"><br>
				<label for="username_usuario" id="lbluser"><img src="image/hiduo2icon.png" width="35"> <?php echo $row['username_usuario'];?></label><br>
				<center><input type="hidden" name="username_usuario" id="username_usuario" class="form-control"></center><center>
				<label id="lbldata" hidden="true"><?php echo $row['idade_usuario'];?></label>
				<center><input type="hidden" id="idade_usuario" class="form-control"></center>
				<label id="lblsexo"><img src="image/sexicon.png" width="20"> <?php echo $sexo;?></label>
				<center><input type="hidden" id="sexo_usuario" class="form-control"></center>
				<label id="lblemail"><img src="image/emailicon.png" width="20"> <?php echo $row['email_usuario'];?></label>
				<center><input type="hidden" id="email_usuario" class="form-control"></center>				
				<label id="lbllol"><img src="image/lolicon.png" width="20"> <?php echo $row['lol_usuario'];?></label>
				<center><input type="hidden" id="lol_usuario" class="form-control"></center>
				<label id="lblow"><img src="image/owicon.png" width="20"> <?php echo $row['over_usuario'];?></label>
				<center><input type="hidden" id="over_usuario" class="form-control"></center>
				<label id="lblpubg"><img src="image/pubgicon.png" width="40"> <?php echo $row['pubg_usuario'];?></label>
				<center><input type="hidden" id="pubg_usuario" class="form-control"></center>
				<label id="lblskype"><img src="image/skypeicon.png" width="20"> <?php echo $row['skype_usuario'];?></label>
				<center><input type="hidden" id="skype_usuario" class="form-control"></center>
				<label id="lblts"><img src="image/tsicon.png" width="30"> <?php echo $row['ts_usuario'];?></label>
				<center><input type="hidden" id="ts_usuario" class="form-control"></center>
				<label id="lbldc"><img src="image/dcicon.png" width="30"> <?php echo $row['discord_usuario'];?></label>				
				<center><input type="hidden" id="discord_usuario" class="form-control"></center>
				<label id="lblestado"><img src="image/estadoicon.png" width="30"> <?php echo $row['estado_usuario'];?></label>
				<center><input type="hidden" id="estado_usuario" class="form-control"></center>
				<br>
				<div class="botoes">
				<a href="perfil.php" class="btn btn-primary">Alterar perfil</a>
				</div> 
			</aside>
		</div>
						
</body>
</html>