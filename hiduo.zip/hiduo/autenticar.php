<?php

require ("conexao.php");

	$username_usuario = $_POST['username_usuario'];
	$senha_usuario = $_POST['senha_usuario'];
	
	$query = mysqli_query($conn,"SELECT * FROM usuario WHERE username_usuario = '$username_usuario' AND senha_usuario = md5('$senha_usuario')");
	$row = mysqli_num_rows($query);

	if ($row > 0){
		session_start();
		$_SESSION['username_usuario'] = $_POST['username_usuario'];
		$_SESSION['senha_usuario'] = $_POST['senha_usuario'];
		header('Location: index.php');
	}else{
		header('Location: login.php?erro=1');
	}
	

?>