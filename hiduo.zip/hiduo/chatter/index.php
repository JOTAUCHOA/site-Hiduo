<?php
	include  "../../hiduo/seguranca.php";
	include '../../hiduo/mensagem.php';
				include "../../hiduo/conexao.php";	

	$sql = "SELECT * FROM usuario WHERE username_usuario = '".$_SESSION['username_usuario']."'";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_array($result);

	$dupla = $row['idDuo_usuario'];

	$sql1 = "SELECT * FROM usuario WHERE id_usuario = '$dupla'";
	$result = mysqli_query($conn, $sql1);
	$row1 = mysqli_fetch_array($result);

	if(isset($_POST['iniciaDuo'])){	
	$user = $_POST['nome_chat'];
	}
		if(isset($_POST['encerraChat'])){

		
			$sqlChat = "TRUNCATE mensagens";
			$rsDelete = mysqli_query($conn, $sqlChat);

			header("location:../../hiduo/index.php");
		
		}

	if(isset($_GET['encerraDuo'])){

	$sql = "SELECT * FROM usuario WHERE username_usuario = '".$_SESSION['username_usuario']."'";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_array($result);
	$session_user = $row['id_usuario'];

			$sqlDuo ="UPDATE `usuario` SET `idDuo_usuario` = '' WHERE `usuario`.`id_usuario` = $session_user;";
			$rsInsert = mysqli_query($conn, $sqlDuo);

		if(mysqli_errno($conn)==0){
		$msg = new Mensagem("Dupla exluida!"," <a href='dupla.php'> Clique aqui para encontrar outra dupla!</a>","success");
	}
	 else {
		 $msg = new Mensagem("Erro","Temos um erro :( ". mysqli_error($conn),"danger");
	}
	}

	$sexo = $row['sexo_usuario'];
	if ($sexo=='G') {
			$sexo="Outro";
		}
	if ($sexo=='M') {
			$sexo="Masculino";
		}
	if ($sexo=='F') {
			$sexo="Feminino";
		}	
?>
<!DOCTYPE html>
<html>
<head>
	<title>HiDuo! - Chat</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
	
	<!-- Fonte do Google -->
	<link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">

		<script
  src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
    <script src="javascript/chat.js"></script>
</head>
<body>
	<div class="body">
		<div class="content">
		<aside style="float: right;">
			<img id="icon" src="<?php echo '../image/icon'.$row1['icone_usuario'].'.png'; ?>" width="150"><br>
				<label for="username_usuario" id="lbluser" style="text-align: left;"><img src="../image/hiduo2icon.png" width="35"><?php echo $row1['username_usuario'];?></label><br>
				<label id="lbldata" hidden="true" style="text-align: left;"><?php echo $row1['idade_usuario'];?></label>
				<label id="lblsexo" style="text-align: left;"><img src="../image/sexicon.png" width="20"> <?php echo $sexo;?></label>
				<label id="lblemail" style="text-align: left;"><img src="../image/emailicon.png" width="20"> <?php echo $row1['email_usuario'];?></label>			
				<label id="lbllol" style="text-align: left;"><img src="../image/lolicon.png" width="20"> <?php echo $row1['lol_usuario'];?></label>
				<label id="lblskype" style="text-align: left;"><img src="../image/skypeicon.png" width="20"> <?php echo $row1['skype_usuario'];?></label>
				<label id="lblts" style="text-align: left;"><img src="../image/tsicon.png" width="30"> <?php echo $row1['ts_usuario'];?></label>
				<label id="lbldc" style="text-align: left;"><img src="../image/dcicon.png" width="30"> <?php echo $row1['discord_usuario'];?></label>				
				<label id="lblestado" style="text-align: left;"><img src="../image/estadoicon.png" width="30"> <?php echo $row1['estado_usuario'];?></label>	
		</aside>
		<aside style="float: left;">
			<img id="icon" src="<?php echo '../image/icon'.$row['icone_usuario'].'.png'; ?>" width="150"><br>
				<label for="username_usuario" id="lbluser" style="text-align: left;"><img src="../image/hiduo2icon.png" width="35"><?php echo $row['username_usuario'];?></label><br>
				<label id="lbldata" hidden="true" style="text-align: left;"><?php echo $row['idade_usuario'];?></label>
				<label id="lblsexo" style="text-align: left;"><img src="../image/sexicon.png" width="20"> <?php echo $sexo;?></label>
				<label id="lblemail" style="text-align: left;"><img src="../image/emailicon.png" width="20"> <?php echo $row['email_usuario'];?></label>			
				<label id="lbllol" style="text-align: left;"><img src="../image/lolicon.png" width="20"> <?php echo $row['lol_usuario'];?></label>
				<label id="lblskype" style="text-align: left;"><img src="../image/skypeicon.png" width="20"> <?php echo $row['skype_usuario'];?></label>
				<label id="lblts" style="text-align: left;"><img src="../image/tsicon.png" width="30"> <?php echo $row['ts_usuario'];?></label>
				<label id="lbldc" style="text-align: left;"><img src="../image/dcicon.png" width="30"> <?php echo $row['discord_usuario'];?></label>				
				<label id="lblestado" style="text-align: left;"><img src="../image/estadoicon.png" width="30"> <?php echo $row['estado_usuario'];?></label>
		</aside>

	<center><div class="chatContainer">
		<div class="chatHeader">
			<h4>Conectado como: <br><?php echo ucwords($user); ?></h4>
		</div>
		<div class="chatMessages">
			<?php 
	//Chamar db
	$db= new PDO('mysql:host=127.0.0.1;dbname=hiduo','root','');

	//pegar mensagens
	$query = $db->prepare("SELECT * FROM mensagens");
	$query->execute();

	//Buscar mensagens
	while($fetch =$query->fetch(PDO::FETCH_ASSOC))
		{
			$name = $fetch['nome_chat'];
			$message = $fetch['mensagem_chat'];

			echo "<li class='cm'><b>".ucwords($name)."</b> - ".$message."</li>";
		}
 ?>
		</div>
		<div class="chatBottom">
			<form action="#" onSubmit="return false;" id="chatForm" method="GET">
				<input type="hidden" name="name" id="name" value='<?php echo $user; ?>' />
				<input type="text" name="text" id="text" placeholder="Digite sua mensagem" />
				<input type="submit" name="submit" value="Enviar" />
			</form>
		</div>
		<br><br>
		<a class='btn btn-info'  href="http://localhost/hiduo/index.php"> Voltar </a><br><br>
	<form action="index.php" method="POST"> <button class='btn btn-info' type='submit' name='encerraChat'> Finalizar duo  </button></form> 	<form action="index.php" method="POST"> <button class='btn btn-danger' type='submit' name='encerraDuo'>Excluir dupla</button></form> 
	

	</div></center>
	

</div>
</body>
</html>