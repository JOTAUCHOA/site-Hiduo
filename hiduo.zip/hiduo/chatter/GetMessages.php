<?php 
	//Chamar db
	$db= new PDO('mysql:host=127.0.0.1;dbname=hiduo','root','');

	//pegar mensagens
	$query = $db->prepare("SELECT * FROM mensagens");
	$query->execute();

	//Buscar mensagens
	while($fetch =$query->fetch(PDO::FETCH_ASSOC))
		{
			$name = $fetch['nome_chat'];
			$message = $fetch['mensagem_chat'];

			echo "<li class='cm'><b>".ucwords($name)."</b> - ".$message."</li>";
		}
 ?>
