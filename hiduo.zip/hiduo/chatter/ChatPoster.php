<?php 
	//chamar o bd
	$db = new PDO('mysql:host=127.0.0.1;dbname=hiduo','root','');

	// SD do chat
	if(isset($_POST['text']) && isset($_POST['name']))
	{
		$text = strip_tags(stripcslashes($_POST['text']));
		$name = strip_tags(stripcslashes($_POST['name']));

		if(!empty($text) && !empty($name))
		{
			$insert = $db->prepare("INSERT INTO mensagens(nome_chat,mensagem_chat) VALUES('".$name."','".$text."')");
			$insert->execute();

			echo "<li class='cm'><b>".ucwords($name)."</b> - ".$text."</li>";
		}
	}
 ?>