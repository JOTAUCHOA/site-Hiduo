<?php
// criar conexao e dar include aqui.
include "conexao.php";
include "seguranca.php";

?>
<html>
	<head>
		<title>HiDuo! - Melhores Duplas </title>
		<meta charset="utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		
		<link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">

		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

		<script type="text/javascript" src="suporte.js"></script>
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		
		<link rel="shortcut icon" href="image/hiduo" type="image/x-icon">
		<link href="css/rank.css" rel="stylesheet">
 		
	<body>
		<nav>
			<form>
					<ul class="nav nav-pills nav-fill nav-justified">
						<li class="nav-item"><a href="index.php" id="active" class="nav-link"><img src="image/hiduoicon.png" width="80"></a></li>
						<li class="nav-item"><a href="dupla.php" class="nav-link">Procurar Dupla</a></li>
						<li class="nav-item"><a href="rank.php" class="nav-link">Melhores Duplas</a></li>
						<li class="nav-item"><a href="suporte.php" class="nav-link">Suporte</a></li>
						<li class="nav-item"><a href="logout.php" class="nav-link">Sair</a></li>
					</ul>
			</form>
		</nav>
			
		</div>
		 <div class="container theme-showcase" role="main">
		<div class="col-md-9">
			<div id="conteudo">
			<h3><strong><p class="text-center">Melhores Duplas do HiDuo!</p></strong></h3>
			<div class="panel panel-default">
	    	<div class="panel-body">
				<table class="table table-hover">
    				<tr>
    				<!-- 	<th style="display:none;">id_usuario</th> -->
						<th> Posição </th>
						<th> Duo </th>
						<th>  </th>
						<th> Data </th>
						<th> Vitórias </th>
						<th> Derrotas </th>					
    				</tr>
					<?php 
						$sqlRank = "SELECT * FROM `duo` ORDER BY `duo`.`vit_duo` DESC"; // Busca todos campos e registros da tabela "Usuarios";
						$rs = mysqli_query($conn, $sqlRank);

					//	$sqlRank = "SELECT duo.user1_duo,duo.user2_duo,duo.jogo_duo,duo.data_duo, usu.id_usuario,usu.username_usuario,usu.elo_usuario,jogo.nome_jogo from duo as duo inner join usuario as usu on duo.user1_duo = usu.id_usuario   inner join jogo as jogo on duo.jogo_duo = jogo.id_jogo ORDER BY `duo`.`vit_duo` DESC";			
					//	$rs = mysqli_query($conn, $sqlRank);	

    		   			while ($duo = mysqli_fetch_array($rs)){
							$user1	   = $duo["user1_duo"];
							$user2		   = $duo["user2_duo"];
							$data_duo 	   = $duo["data_duo"];
							$vit_duo 	   = $duo["vit_duo"];
							$der_duo 	   = $duo["der_duo"];
							$posicao++;
										
    		   			echo "<tr>";
						echo "<td>#$posicao</td>";
						echo "<td>$user1</td>";
						echo "<td>$user2</td>";
						echo "<td>$data_duo</td>";
						echo "<td>$vit_duo</td>";
						echo "<td>$der_duo</td>";						
						echo "</tr>";									
						} 
					?>	
    			</table>
			</div>	
			</div>
		</div>
		</div>	
	</body>
</html>