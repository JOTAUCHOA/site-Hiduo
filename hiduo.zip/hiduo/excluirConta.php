<?php  
	
 include 'conexao.php';
 include 'seguranca.php';

if(isset($_POST['submit'])){


	$sqlDelete = "DELETE FROM usuario WHERE username_usuario = '".$_SESSION['username_usuario']."' ";

	$rsEdit = mysqli_query($conn, $sqlDelete);
	if(mysqli_errno($conn)==0){
		header('Location: login.php');
	}
	 else {
		 echo("Erro: ". mysqli_errno($conn));
		}
		mysqli_close($conn);
}

?>
<!DOCTYPE html>
<html>
<head>
	<title> HiDuo! - Excluir conta </title>

<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">

	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="">

	<!-- Bootstrap -->	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
	

	<!-- Fonte do Google -->
	<link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">

	<!-- Favicon -->
	<link rel="shortcut icon" href="hiduo2.png" type="image/x-icon">

</head>
<body>

	<form method="POST" action="excluirConta.php">			
	<h1> Tem certeza que deseja excluir sua conta?  <button class="btn btn-danger" type="submit" name="submit" value="submit"> Sim </button> </h1>
	<h3> Todos seus dados serão perdidos, essa é uma ação sem volta. </h3>
</form>
</body>
</html>