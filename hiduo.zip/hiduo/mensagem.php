<?php
//Mensagem.php

class Mensagem{
	private $titulo;
	private $texto;
	private $tipo; //mensagem de erro, sucesso, pergunta, etc;
	
	function __construct($titulo, $texto, $tipo){
		$this->titulo = $titulo;
		$this->texto = $texto;
		$this->tipo = $tipo;
	}

	function mostrar(){
		echo "<div class='alert alert-".$this->tipo."' role='alert'>";
		echo "<h4>".$this->titulo."</h4> ";
		echo $this->texto;
		echo "</div>";
	}
}
?>