-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 07-Maio-2018 às 03:07
-- Versão do servidor: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hiduo`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `duo`
--

CREATE TABLE `duo` (
  `id_duo` int(11) NOT NULL,
  `user1_duo` int(11) NOT NULL,
  `user2_duo` int(11) NOT NULL,
  `data_duo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vit_duo` int(11) DEFAULT NULL,
  `der_duo` int(11) DEFAULT NULL,
  `jogo_duo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `duo`
--

INSERT INTO `duo` (`id_duo`, `user1_duo`, `user2_duo`, `data_duo`, `vit_duo`, `der_duo`, `jogo_duo`) VALUES
(14, 11, 7, '2018-04-19 16:32:59', 65, 8, 1),
(23, 8, 9, '2018-05-04 00:40:53', 5000, 0, 1),
(25, 6, 7, '2018-05-04 22:10:51', NULL, NULL, 1),
(26, 10, 8, '2018-05-04 22:48:53', NULL, NULL, 1),
(27, 6, 7, '2018-05-07 00:45:02', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `jogo`
--

CREATE TABLE `jogo` (
  `id_jogo` int(11) NOT NULL,
  `nome_jogo` varchar(60) NOT NULL,
  `descricao_jogo` text NOT NULL,
  `genero_jogo` varchar(60) NOT NULL,
  `produtora_jogo` varchar(60) NOT NULL,
  `qtdeUsers_jogo` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `jogo`
--

INSERT INTO `jogo` (`id_jogo`, `nome_jogo`, `descricao_jogo`, `genero_jogo`, `produtora_jogo`, `qtdeUsers_jogo`) VALUES
(1, 'League Of Legends', 'League of Legends is a multiplayer online battle arena video game developed and published by Riot Games for Microsoft Windows and macOS.', 'MOBA', 'Riot Games', 7),
(2, 'PlayerUnknown\'s Battlegrounds', 'PlayerUnknown\'s Battlegrounds is a multiplayer online battle royale game developed and published by PUBG Corporation, a subsidiary of publisher Bluehole.', 'FPS', 'PUBG Corporation and Bluehole', 0),
(3, 'Overwatch', 'Overwatch is a team-based multiplayer first-person shooter video game developed and published by Blizzard Entertainment, which released on May 24, 2016 for PlayStation 4, Xbox One, and Windows.', 'FPS', 'Blizzard Entertainment', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `id_chat` int(11) NOT NULL,
  `nome_chat` varchar(60) NOT NULL,
  `mensagem_chat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `solicitacoes`
--

CREATE TABLE `solicitacoes` (
  `id_soli` int(11) NOT NULL,
  `solicitante_soli` int(11) NOT NULL,
  `solicitado_soli` int(11) NOT NULL,
  `jogo_soli` int(11) NOT NULL,
  `data_soli` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `suporte`
--

CREATE TABLE `suporte` (
  `id_suporte` int(11) NOT NULL,
  `data_suporte` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nome_suporte` varchar(60) NOT NULL,
  `email_suporte` varchar(60) NOT NULL,
  `assunto_suporte` varchar(60) NOT NULL,
  `categoria_suporte` varchar(60) NOT NULL,
  `msg_suporte` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `suporte`
--

INSERT INTO `suporte` (`id_suporte`, `data_suporte`, `nome_suporte`, `email_suporte`, `assunto_suporte`, `categoria_suporte`, `msg_suporte`) VALUES
(1, '2018-05-03 22:13:28', 'Giovana', 'gioavana@email.com', 'Amei o site', 'Elogios', 'Ele é muito intuitivo, alem de ser intuitivo, o seu design cativa bastante, pois faz usa-lo com muita decorrência.						');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nome_usuario` varchar(60) NOT NULL,
  `idade_usuario` date NOT NULL,
  `sexo_usuario` varchar(1) NOT NULL,
  `email_usuario` varchar(120) NOT NULL,
  `username_usuario` varchar(60) NOT NULL,
  `senha_usuario` varchar(80) NOT NULL,
  `lol_usuario` varchar(60) NOT NULL,
  `skype_usuario` varchar(60) NOT NULL,
  `ts_usuario` varchar(60) NOT NULL,
  `discord_usuario` varchar(60) NOT NULL,
  `icone_usuario` int(2) NOT NULL,
  `elo_usuario` varchar(30) DEFAULT NULL,
  `estado_usuario` varchar(30) NOT NULL,
  `idDuo_usuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nome_usuario`, `idade_usuario`, `sexo_usuario`, `email_usuario`, `username_usuario`, `senha_usuario`, `lol_usuario`, `skype_usuario`, `ts_usuario`, `discord_usuario`, `icone_usuario`, `elo_usuario`, `estado_usuario`, `idDuo_usuario`) VALUES
(6, 'Raphael Passos', '1996-07-01', 'M', 'rapha2551@gmail.com', 'rpassos', '827ccb0eea8a706c4c34a16891f84e7b', 'SoloQ Rapha RX SL', 'rapha 10 CM', 'grimorio.com', '#4435', 8, 'bronze', 'AM', 0),
(7, 'Guilherme Rodrigues', '1999-07-01', 'M', 'guilherme@email.com', 'nonTyus', '827ccb0eea8a706c4c34a16891f84e7b', 'nonTyus', 'gui.twd', 'tca.com.br', '#6666', 9, 'prata', 'PI', 0),
(8, 'Denilson Pereira', '1998-07-01', 'F', 'deene67@gmail.com', 'dpereira', '827ccb0eea8a706c4c34a16891f84e7b', 'Dede homo', 'dede 8CM', 'corinthianos.com.br', '#8787', 2, 'ouro', 'AL', 0),
(9, 'Emerson Sena', '1999-07-01', 'F', 'emerson.sena12@gmail.com', 'esena', '827ccb0eea8a706c4c34a16891f84e7b', 'SoloQ Seninha', 'Emerson 27CM', '', '#5656', 6, 'platina', 'DF', 0),
(10, 'Jose Freire', '1999-07-01', 'M', 'zeaugusto@gmail.com', 'jfreire', '827ccb0eea8a706c4c34a16891f84e7b', 'freirezinho', 'Jose 10CM', '', '#9012', 1, 'diamante', 'RR', 0),
(11, 'Gustavo Almeida', '1999-03-19', 'M', 'gars1999@gmail.com', 'galmeida', '827ccb0eea8a706c4c34a16891f84e7b', 'JasonYT', 'JasonYT', 'JasonYT.com.br', '#1234', 5, 'mestre', 'SP', 0),
(22, 'Administrador', '2001-06-04', 'M', 'admin@admin.com', 'admin', '827ccb0eea8a706c4c34a16891f84e7b', 'Ryze', 'admin 32CM', 'admin.com.br', 'adminDD', 3, NULL, 'CE', NULL),
(27, 'Teste', '1991-06-18', 'F', 'testeaa@gmail.com', 'AAAAAAAAAAAAAAAAAAAAAAA', 'd41d8cd98f00b204e9800998ecf8427e', '', '', '', '', 4, NULL, 'ES', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `duo`
--
ALTER TABLE `duo`
  ADD PRIMARY KEY (`id_duo`),
  ADD KEY `jogo_duo` (`jogo_duo`),
  ADD KEY `user1_duo` (`user1_duo`,`user2_duo`),
  ADD KEY `user2_duo` (`user2_duo`);

--
-- Indexes for table `jogo`
--
ALTER TABLE `jogo`
  ADD PRIMARY KEY (`id_jogo`);

--
-- Indexes for table `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`id_chat`);

--
-- Indexes for table `solicitacoes`
--
ALTER TABLE `solicitacoes`
  ADD PRIMARY KEY (`id_soli`),
  ADD KEY `jogo_soli` (`jogo_soli`),
  ADD KEY `player1_soli` (`solicitante_soli`,`solicitado_soli`),
  ADD KEY `player2_soli` (`solicitado_soli`);

--
-- Indexes for table `suporte`
--
ALTER TABLE `suporte`
  ADD PRIMARY KEY (`id_suporte`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email_usuario` (`email_usuario`),
  ADD UNIQUE KEY `username_usuario` (`username_usuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `duo`
--
ALTER TABLE `duo`
  MODIFY `id_duo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `jogo`
--
ALTER TABLE `jogo`
  MODIFY `id_jogo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `id_chat` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `solicitacoes`
--
ALTER TABLE `solicitacoes`
  MODIFY `id_soli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `suporte`
--
ALTER TABLE `suporte`
  MODIFY `id_suporte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `duo`
--
ALTER TABLE `duo`
  ADD CONSTRAINT `jogo_duo` FOREIGN KEY (`jogo_duo`) REFERENCES `jogo` (`id_jogo`),
  ADD CONSTRAINT `user1_duo` FOREIGN KEY (`user1_duo`) REFERENCES `usuario` (`id_usuario`),
  ADD CONSTRAINT `user2_duo` FOREIGN KEY (`user2_duo`) REFERENCES `usuario` (`id_usuario`);

--
-- Limitadores para a tabela `solicitacoes`
--
ALTER TABLE `solicitacoes`
  ADD CONSTRAINT `jogo_soli` FOREIGN KEY (`jogo_soli`) REFERENCES `jogo` (`id_jogo`),
  ADD CONSTRAINT `player1_soli` FOREIGN KEY (`solicitante_soli`) REFERENCES `usuario` (`id_usuario`),
  ADD CONSTRAINT `player2_soli` FOREIGN KEY (`solicitado_soli`) REFERENCES `usuario` (`id_usuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
