<?php 
	//error_reporting(0); 
	include 'mensagem.php'; 
	include  'conexao.php';
	include  'seguranca.php';

if(isset($_GET['solicitaDuo'])){

	$sql = "SELECT * FROM usuario WHERE username_usuario = '".$_SESSION['username_usuario']."'";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_array( $result);

	$session_user = $row['id_usuario'];
	$player2 = $_GET['player2_soli'];

	$sqlDuo ="INSERT INTO `solicitacoes` (`solicitante_soli`, `solicitado_soli`, `jogo_soli`) VALUES ('$session_user', '$player2', '1')";
	$rsInsert = mysqli_query($conn, $sqlDuo);

	if(mysqli_errno($conn)==0){
		$msg = new Mensagem("Solicitação enviada!","Aguarde a confirmação do usuário!","success");
	}
	 else {
		 $msg = new Mensagem("Erro","Temos um erro :( ". mysqli_error($conn),"danger");
	}
}						
?>
<html>
	<head>
		<title>HiDuo! - Dupla</title>
		<meta charset="utf-8">
	
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		
		<link rel="shortcut icon" href="image/hiduo2.png" type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="css/dupla1.css">
		<link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">
	</head>
	<body>
	<nav>
			<form>
					<ul class="nav nav-pills nav-fill nav-justified">
						<li class="nav-item"><a href="index.php" id="active" class="nav-link"><img src="image/hiduoicon.png" width="80"></a></li>
						<li class="nav-item"><a href="dupla.php" class="nav-link">Procurar Dupla</a></li>
						<li class="nav-item"><a href="rank.php" class="nav-link">Melhores Duplas</a></li>
						<li class="nav-item"><a href="suporte.php" class="nav-link">Suporte</a></li>
						<li class="nav-item"><a href="logout.php" class="nav-link">Sair</a></li>
					</ul>
			</form>
		</nav>
		<div id="conteudo">
			<h3><strong><p class="text-center">Selecione o Jogo:</p></strong></h3>
			<?php
		if(isset($msg)) $msg->mostrar();
		?>	
			<div class="col-md-5">	
				<div class="OpcoesDeJogos">
					<a href="#lolForm" onclick="lolForm()" ><img src="image/lol.jpg" width="100%" height="100%" class="img-responsive center-block"></a><br><br>
					<div id="lolForm" style="display: none;">
					<form action="dupla.php" method="GET" class="form-group">
						<div class="form-group">
					<div>
						<label> Selecione o elo: </label>
						<br>
						<div class="col-xs-4">
						<select class="form-control" name="elo_usuario">
							<option value="" selected disabled>Selecione o elo </option>
							<option value= "" selected=""> Todos </option>
							<option value= "unraked"> Sem ranqueamento </option>
							<option value= "bronze"> Bronze </option>
							<option value= "prata"> Prata </option>
							<option value= "ouro"> Ouro </option>
							<option value= "platina"> Platina </option>
							<option value= "diamante"> Diamante </option>
							<option value= "mestre"> Mestre </option>
							<option value= "desafiante"> Desafiante </option>
						</select>
						</div>
					</div>
					
					<button class="btn btn-primary btn-sm" type="submit" name="procuraDuo" >  Procurar dupla </button>
					</div>
					</form>
				</div>
			
			<div>
			<div class="panel panel-default">
	    	<div class="panel-body" >
    			<table class="table table-hover"  >
    				<tr>
						<th> HiDuo </th>
						<th> Nick </th>
						<th> Elo </th>						
						<th> Escolher </th>
    				</tr>
					<?php 

					//error_reporting(0);

					if(isset($_GET['procuraDuo'])){

						$sql = "SELECT * FROM usuario WHERE username_usuario = '".$_SESSION['username_usuario']."'";
						$result = mysqli_query($conn, $sql);
						$row = mysqli_fetch_array( $result);
						$session_user = $row['id_usuario'];

						$elo_usuario=$_GET['elo_usuario'];	

						$sqlPesquisa = "SELECT * FROM usuario WHERE elo_usuario LIKE '%$elo_usuario%' AND id_usuario != '$session_user'" ; // Busca todos campos e registros da tabela "Usuarios";
						$rs = mysqli_query($conn, $sqlPesquisa);

    		   			while ($usuario = mysqli_fetch_array($rs)){
							$id_duo	   		   = $usuario["id_usuario"];
							$username_usuario  = $usuario["username_usuario"];
							$lol_usuario 	   = $usuario["lol_usuario"];
							$elo_usuario 	   = $usuario["elo_usuario"];
							
						$onClick = "confirmar($id_duo,'$username_usuario','$elo_usuario');";

    		   			echo "<tr>";
						echo "<td>$username_usuario</td>";
						echo "<td>$lol_usuario</td>";
						echo "<td>$elo_usuario</td>";						
						echo "<td>";
						echo " <button class='btn btn-success' type='submit'  onClick=\"$onClick\" data-toggle='modal' data-target='#myModal'> <i class='glyphicon glyphicon-ok'></i>  </button>";
						echo "</td>";
						echo "</tr>";									
						} 
					}							
					?>	
    			</table>
    			</form>
    		</div>
</div>
        	</div>
</div>
</div>

	<div class="col-md-5">	
				<div class="OpcoesDeJogos">
					<a href="#jogoForm" onclick="jogoForm()" ><img src="image/ow.jpg" width="100%" height="100%" class="img-responsive center-block"></a><br><br>
					<div id="jogoForm" style="display: none;">
							<form action="dupla.php" method="GET" class="form-group">
						<div class="form-group">
					
						<label> Selecione um jogo: </label>
						<br>
						<div class="col-xs-4">
						<select class="form-control" name="jogo">
							<option value="" selected disabled>Selecione o jogo </option>
							<option value= "overwatch"> Overwatch </option>
							<option value= "pubg"> PUBG </option>
							<option value= "fortnite"> Fortnite </option>
						</select>
						</div>
				
					
					<button class="btn btn-primary btn-sm" type="submit" name="procuraDuo"> Procurar dupla </button>
					</div>
					</form>
				</div>
			
			<div class="panel panel-default">
	    	<div class="panel-body">
    			<table class="table table-hover">
    				<tr>
						<th> HiDuo </th>
						<th> Sexo </th>					
						<th> Idade </th>					
						<th> Escolher </th>
    				</tr>
					<?php 

					//error_reporting(0);

					if(isset($_GET['procuraJogo'])){

						$sql = "SELECT * FROM usuario WHERE username_usuario = '".$_SESSION['username_usuario']."'";
						$result = mysqli_query($conn, $sql);
						$row = mysqli_fetch_array( $result);
						$session_user = $row['id_usuario'];

						$elo_usuario=$_GET['elo_usuario'];	

						$sqlPesquisa = "SELECT * FROM usuario WHERE elo_usuario LIKE '%$elo_usuario%' AND id_usuario != '$session_user'" ; // Busca todos campos e registros da tabela "Usuarios";
						$rs = mysqli_query($conn, $sqlPesquisa);

    		   			while ($usuario = mysqli_fetch_array($rs)){
							$id_duo	   		   = $usuario["id_usuario"];
							$username_usuario  = $usuario["username_usuario"];
							$lol_usuario 	   = $usuario["lol_usuario"];
							$elo_usuario 	   = $usuario["elo_usuario"];
							
						$onClick = "confirmar($id_duo,'$username_usuario','$elo_usuario');";

    		   			echo "<tr>";
						echo "<td>$username_usuario</td>";
						echo "<td>$lol_usuario</td>";
						echo "<td>$elo_usuario</td>";						
						echo "<td>";
						echo " <button class='btn btn-success' type='submit'  onClick=\"$onClick\" data-toggle='modal' data-target='#myModal'> <i class='glyphicon glyphicon-ok'></i>  </button>";
						echo "</td>";
						echo "</tr>";									
						} 
					}							
					?>	
    			</table>
    			</form>
    		</div>

        	</div>
</div>
</div>

		<div class="container">
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="color: black;">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Confirme sua escolha!</h4>
        </div>
        <form action="dupla.php" method="GET">
        <div class="modal-body">
          <p>Você selecionou o <input type="hidden" name="player2_soli" id="resposta1"> <input type="text" id="resposta2"> que está no <input type="text" id="resposta3">!
           </p>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success" name="solicitaDuo" >Confimar escolha</button>
      </form>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

		<script type="text/javascript"> 
		function confirmar(id_duo,username_usuario, elo_usuario) {
			document.getElementById('resposta1').value = id_duo;
			document.getElementById('resposta2').value = username_usuario;
			document.getElementById('resposta3').value = elo_usuario;
		}
		</script>

	<script>
     function lolForm()
     {
           var div = document.getElementById("lolForm");
    if (div.style.display !== "none") {
        div.style.display = "none";
    }
    else {
        div.style.display = "block";
    }
    	var div = document.getElementById("jogoForm");
    if (div.style.display !=="none"){
    	div.style.display = "none";
    }
       var div = document.getElementById("resultadoLol");
    if (div.style.display == "none") {
        div.style.display = "";
    }

     }
  </script>

  	<script>
     function jogoForm()
     {
           var div = document.getElementById("jogoForm");
    if (div.style.display !== "none") {
        div.style.display = "none";
    }
    else {
        div.style.display = "block";
    }
    	var div = document.getElementById("lolForm");
    if (div.style.display !=="none"){
    	div.style.display = "none";
    }
       }
  </script>
	</body>
</html>			