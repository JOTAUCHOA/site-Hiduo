<?php 
	include 'conexao.php';
	include 'mensagem.php';
 ?>

<html>
<head>
	<title>HiDuo! - Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">

	<!-- CSS-->
	<link rel="stylesheet" type="text/css" href="css/login.css">

	<!-- Bootstrap 4.0-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">

	<!-- Fonte do Google xD   -->
		<link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">

	<!-- Favicon -->
	<link rel="shortcut icon" href="hiduo2.png" type="image/x-icon">

<body>
	<div class="body">
		<img src="image/hiduo.png">
		<div class="content">
			<div class="video float-left">
				<h1 class="text-light">Conheça o HiDuo. A nova forma de conhecer outros gamers!</h1>
				<iframe width="560" height="315" src="https://www.youtube.com/embed/2gUtfBmw86Y" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
			</div>
			
			<div class="login float-right">
				<form action="autenticar.php" method="POST">
					<label for="user" class="font-weight-bold">Usuário</label>
					<center><input class="form-control" type="text" name="username_usuario" id="user" autofocus=""></center>
					<label for="password" class="font-weight-bold">Senha</label>
					<center><input class="form-control" name="senha_usuario" type="password" id="password"></center>
					<input type="submit" class="btn btn-info" value="Entrar" id="logar">
					 <?php if (isset($_GET["erro"])){ 
             		 if ($_GET["erro"]==1) $msg = "Usuários e/ou senhas incorretos";
             		 if ($_GET["erro"]==2) $msg = "Você precisa estar logado para acessar essa página.";
        			 ?>
        			   <div class="alert alert-danger form-control">
      				  <p class="text-center"> <?php echo $msg; ?> </p>  
     				 </div>
     				 <?php } ?>
					<a href="cadastro.php"><input type="button" class="btn btn-link" value="Não possui conta? Cadastre-se!" id="cadastro"></a>
				</form>
			
			</div>
		<footer class="footer rounded">			
			<img src="image/cats2.png" height="100" width="100" class="float-left">
			<img src="image/hiduo1.png" height="100" width="100" class="float-right">
			<h4 class="text-light">© 2018 Cats2, Inc. Todas as artes dos jogos são propiedade de suas devidas organizações.</h4>		
		</footer>
		</div>
</body>
</html>