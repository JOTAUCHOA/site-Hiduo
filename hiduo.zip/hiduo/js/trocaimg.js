var i =0;
var images =[];
var time = 1000;

images[0] = '.../image/icon1.png';
images[1] = 'localhost/hiduo/image/icon2.png';
images[2] = 'hiduo/image/icon3.png';


function trocaImg(){
	document.troca.src = images[i];

	if (i<images.length - 1) {
		i++;
	}else{
		i=0;
	}
	setTimeout("trocaImg()",time);
}

window.onload = trocaImg;