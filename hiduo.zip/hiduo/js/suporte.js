
function validaAssunto(){
	var assunto = document.getElementById('assunto');
	caixa_assunto = document.querySelector('.msg-assunto');

	if(assunto.value == ""){
		caixa_assunto.innerHTML = "Favor preencher o assunto";
		caixa_assunto.style.display = 'block';
		return false;
	}else if(assunto.value.length < 5){
		caixa_assunto.innerHTML = "Favor preencher a assunto com o mínimo de 5 caracteres";
		caixa_assunto.style.display = 'block';
		return false;
	}else{
		caixa_assunto.innerHTML = "";
		caixa_assunto.style.color = "none";
		return true;
	}

}

function validaSuporte(){
	var tipo  = document.getElementById('suporte');
	var texto = document.getElementById('Texto');
	caixa_texto = document.querySelector('.msg-texto');
	caixa_tipo = document.querySelector('.msg-tipo');

	if(tipo.selectedIndex==0){
		caixa_tipo.innerHTML = "Escolha uma opção";
		caixa_tipo.style.display = 'block';
		return false;
	}else{
		caixa_tipo.innerHTML = "";
		caixa_tipo.style.color="none"
		return true;
	}

	if(texto.value == 0){
		caixa_texto.innerHTML = "Escolha uma opção";
		caixa_texto.style.display = 'block';
		return false;
	}else{
		caixa_texto.innerHTML = "";
		caixa_texto.style.color="none"
		return true;
	}

}