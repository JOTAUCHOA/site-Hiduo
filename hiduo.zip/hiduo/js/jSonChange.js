﻿function validarNome(){	
	var nome = document.getElementById('nome');
	caixa_nome = document.querySelector('.msg-nome');
	if(nome.value == ""){
		caixa_nome.innerHTML = "Favor preencher o nome";
		caixa_nome.style.display = 'block';
		return false;	
	}else if(nome.value.length < 5){
		caixa_nome.innerHTML = "Favor preencher a nome com o mínimo de 5 caracteres";
		caixa_nome.style.display = 'block';
		return false;
	}else{
		caixa_nome.innerHTML = "";
		caixa_nome.style.color = "none";
		return true;
	}
}

function validarUser(){	
	var username = document.getElementById('username');
	caixa_username = document.querySelector('.msg-user');
	if(username.value == ""){
		caixa_username.innerHTML = "Campo usuário vazio!";
		caixa_username.style.display = 'block';
		return false;		
	}else if(username.value.length < 5){
		caixa_username.innerHTML = "Favor preencher usuário com o mínimo de 5 caracteres";
		caixa_username.style.display = 'block';
		return false;
	}else{
		caixa_username.innerHTML = "";
		caixa_username.style.color = "none";
		return true;
	}
}

function validarSenha(){
	var senha = document.getElementById('senha');
	caixa_senha = document.querySelector('.msg-senha');
	if(senha.value == ""){
		caixa_senha.innerHTML = "Favor preencher a Senha";
		caixa_senha.style.display = 'block';
		return false;		
	}else if(senha.value.length < 5){
		caixa_senha.innerHTML = "Favor preencher a Senha com o mínimo de 5 caracteres";
		caixa_senha.style.display = 'block';
		return false;	
	}else{
		caixa_senha.innerHTML = "";
		caixa_senha.style.color = "none";
		return true;
	}
}

function validarSenha2(){
	//var senha = document.getElementById('senha');
	var senha2 = document.getElementById('senha2');
	caixa_senha2 = document.querySelector('.msg-senha2');
	if(senha2.value == ""){
		caixa_senha2.innerHTML = "Favor preencher o campo de Confirmação de Senha";
		caixa_senha2.style.display = 'block';
		return false;		
	}else if(senha2.value.length < 8){
		caixa_senha2.innerHTML = "Favor preencher o campo de Confirmação de Senha com o mínimo de 8 caracteres";
		caixa_senha2.style.display = 'block';
		return false;
	}else if(senha.value != senha2.value){
		caixa_senha2.innerHTML="Senhas diferentes";	
		return false;
	}else{
		caixa_senha2.innerHTML = "";
		caixa_senha2.style.color = "none";
		return true;	
			
	}	
}

function validarSexo(){
	var sexo = document.getElementById('sexo');
	caixa_sexo = document.querySelector('.msg-sexo');
	if(sexo.selectedIndex==0){
		caixa_sexo.innerHTML = "Favor selecione o sexo";
		caixa_sexo.style.display = 'block';
		return false;
	}else{
		caixa_sexo.innerHTML = "";
		caixa_sexo.style.color = "none";
		return true;		
	}
}

function validarEstado(){
	var estado = document.getElementById('estado');
	caixa_estado = document.querySelector('.msg-estado');
	if(estado.selectedIndex==0){
		caixa_estado.innerHTML = "Favor selecione o estado";
		caixa_estado.style.display = 'block';
		return false;
	}else{
		caixa_estado.innerHTML = "";
		caixa_estado.style.color = "none";
		return true;		
	}
}


function validarLOL(){	
	var lol = document.getElementById('lol');
	caixa_lol = document.querySelector('.msg-lol');
	if(lol.value == ""){
		caixa_lol.innerHTML = "Favor preencher o nick do LOL";
		caixa_lol.style.display = 'block';
		return false;	
	}else if(lol.value.length < 3){
		caixa_lol.innerHTML = "Favor preencher o campo lol com o mínimo de 3 caracteres";
		caixa_lol.style.display = 'block';
		return false;
	}else{
		caixa_lol.innerHTML = "";
		caixa_lol.style.color = "none";
		return true;
	}
}

function validarData(){
	var dia = document.getElementById('dia');
	var mes = document.getElementById('mes');
	var ano = document.getElementById('ano');
	caixa_data = document.querySelector('.msg-data');
	if(dia.selectedIndex==0 && mes.selectedIndex==0 && ano.selectedIndex==0){
		caixa_data.innerHTML = "Favor selecione a data de nascimento";
		caixa_data.style.display = 'block';
		return false;
	}else{
		caixa_data.innerHTML = "";
		caixa_data.style.color = "none";
		return true;		
	}
}

function validarEmail(){
	var email = document.getElementById('email');
	var filtro = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	caixa_email = document.querySelector('.msg-email');
	if(email.value == ""){
		caixa_email.innerHTML = "Favor preencher o E-mail";
		caixa_email.style.display = 'block';
		return false;
	}else if(filtro.test(email.value)){
		caixa_email.innerHTML = "";
		caixa_email.style.color = "none";
		return true;
	}else{
		caixa_email.innerHTML = "Formato do E-mail inválido";
		caixa_email.style.display = 'block';
		return false;
	}	

}

function teste(){
setTimeout("validarNome()",5000);
setTimeout("validarUser()",5000);
setTimeout("validarSenha()",5000);
setTimeout("validarSenha2()",5000);
setTimeout("validarSexo()",5000);
setTimeout("validarEstado()",5000);
setTimeout("validarSexo()",5000);
setTimeout("validarLOL()",5000);
setTimeout("validarData()",5000);
setTimeout("validarEmail()",5000);
}

		function icone(valor) {
			var v = valor;
			if (v == 1){
					document.getElementById('icon1').style	= "padding:8px;background-color: #00D6FF";
					document.getElementById('icon2').style	= "padding:4px;background-color: white";
					document.getElementById('icon3').style	= "padding:4px;background-color: white";
					document.getElementById('icon4').style	= "padding:4px;background-color: white";
					document.getElementById('icon5').style	= "padding:4px;background-color: white";
					document.getElementById('icon6').style	= "padding:4px;background-color: white";
					document.getElementById('icon7').style	= "padding:4px;background-color: white";
					document.getElementById('icon8').style	= "padding:4px;background-color: white";
					document.getElementById('icon9').style	= "padding:4px;background-color: white";
					document.getElementById('icon0').style	= "padding:4px;background-color: white";
				}
			if (v == 2){
					document.getElementById('icon2').style	= "padding:8px;background-color: #00D6FF";
					document.getElementById('icon1').style	= "padding:4px;background-color: white";
					document.getElementById('icon3').style	= "padding:4px;background-color: white";
					document.getElementById('icon4').style	= "padding:4px;background-color: white";
					document.getElementById('icon5').style	= "padding:4px;background-color: white";
					document.getElementById('icon6').style	= "padding:4px;background-color: white";
					document.getElementById('icon7').style	= "padding:4px;background-color: white";
					document.getElementById('icon8').style	= "padding:4px;background-color: white";
					document.getElementById('icon9').style	= "padding:4px;background-color: white";
					document.getElementById('icon0').style	= "padding:4px;background-color: white";
				}
			if (v == 3){
					document.getElementById('icon3').style	= "padding:8px;background-color: #00D6FF";
					document.getElementById('icon1').style	= "padding:4px;background-color: white";
					document.getElementById('icon2').style	= "padding:4px;background-color: white";
					document.getElementById('icon4').style	= "padding:4px;background-color: white";
					document.getElementById('icon5').style	= "padding:4px;background-color: white";
					document.getElementById('icon6').style	= "padding:4px;background-color: white";
					document.getElementById('icon7').style	= "padding:4px;background-color: white";
					document.getElementById('icon8').style	= "padding:4px;background-color: white";
					document.getElementById('icon9').style	= "padding:4px;background-color: white";
					document.getElementById('icon0').style	= "padding:4px;background-color: white";
				}
			if (v == 4){
					document.getElementById('icon4').style	= "padding:8px;background-color: #00D6FF";
					document.getElementById('icon1').style	= "padding:4px;background-color: white";
					document.getElementById('icon2').style	= "padding:4px;background-color: white";
					document.getElementById('icon3').style	= "padding:4px;background-color: white";
					document.getElementById('icon5').style	= "padding:4px;background-color: white";
					document.getElementById('icon6').style	= "padding:4px;background-color: white";
					document.getElementById('icon7').style	= "padding:4px;background-color: white";
					document.getElementById('icon8').style	= "padding:4px;background-color: white";
					document.getElementById('icon9').style	= "padding:4px;background-color: white";
					document.getElementById('icon0').style	= "padding:4px;background-color: white";
				}
			if (v == 5){
					document.getElementById('icon5').style	= "padding:8px;background-color: #00D6FF";
					document.getElementById('icon1').style	= "padding:4px;background-color: white";
					document.getElementById('icon2').style	= "padding:4px;background-color: white";
					document.getElementById('icon3').style	= "padding:4px;background-color: white";
					document.getElementById('icon4').style	= "padding:4px;background-color: white";
					document.getElementById('icon6').style	= "padding:4px;background-color: white";
					document.getElementById('icon7').style	= "padding:4px;background-color: white";
					document.getElementById('icon8').style	= "padding:4px;background-color: white";
					document.getElementById('icon9').style	= "padding:4px;background-color: white";
					document.getElementById('icon0').style	= "padding:4px;background-color: white";
				}
			if (v == 6){
					document.getElementById('icon6').style	= "padding:8px;background-color: #00D6FF";
					document.getElementById('icon1').style	= "padding:4px;background-color: white";
					document.getElementById('icon2').style	= "padding:4px;background-color: white";
					document.getElementById('icon3').style	= "padding:4px;background-color: white";
					document.getElementById('icon4').style	= "padding:4px;background-color: white";
					document.getElementById('icon5').style	= "padding:4px;background-color: white";
					document.getElementById('icon7').style	= "padding:4px;background-color: white";
					document.getElementById('icon8').style	= "padding:4px;background-color: white";
					document.getElementById('icon9').style	= "padding:4px;background-color: white";
					document.getElementById('icon0').style	= "padding:4px;background-color: white";
				}
			if (v == 7){
					document.getElementById('icon7').style	= "padding:8px;background-color: #00D6FF";
					document.getElementById('icon1').style	= "padding:4px;background-color: white";
					document.getElementById('icon2').style	= "padding:4px;background-color: white";
					document.getElementById('icon3').style	= "padding:4px;background-color: white";
					document.getElementById('icon4').style	= "padding:4px;background-color: white";
					document.getElementById('icon5').style	= "padding:4px;background-color: white";
					document.getElementById('icon6').style	= "padding:4px;background-color: white";
					document.getElementById('icon8').style	= "padding:4px;background-color: white";
					document.getElementById('icon9').style	= "padding:4px;background-color: white";
					document.getElementById('icon0').style	= "padding:4px;background-color: white";
				}
			if (v == 8){
					document.getElementById('icon8').style	= "padding:8px;background-color: #00D6FF";
					document.getElementById('icon1').style	= "padding:4px;background-color: white";
					document.getElementById('icon2').style	= "padding:4px;background-color: white";
					document.getElementById('icon3').style	= "padding:4px;background-color: white";
					document.getElementById('icon4').style	= "padding:4px;background-color: white";
					document.getElementById('icon5').style	= "padding:4px;background-color: white";
					document.getElementById('icon6').style	= "padding:4px;background-color: white";
					document.getElementById('icon7').style	= "padding:4px;background-color: white";
					document.getElementById('icon9').style	= "padding:4px;background-color: white";
					document.getElementById('icon0').style	= "padding:4px;background-color: white";
				}
			if (v == 9){
					document.getElementById('icon9').style	= "padding:8px;background-color: #00D6FF";
					document.getElementById('icon1').style	= "padding:4px;background-color: white";
					document.getElementById('icon2').style	= "padding:4px;background-color: white";
					document.getElementById('icon3').style	= "padding:4px;background-color: white";
					document.getElementById('icon4').style	= "padding:4px;background-color: white";
					document.getElementById('icon5').style	= "padding:4px;background-color: white";
					document.getElementById('icon6').style	= "padding:4px;background-color: white";
					document.getElementById('icon7').style	= "padding:4px;background-color: white";
					document.getElementById('icon8').style	= "padding:4px;background-color: white";
					document.getElementById('icon0').style	= "padding:4px;background-color: white";
				}
			if (v == 0){
					document.getElementById('icon0').style	= "padding:8px;background-color: #00D6FF";
					document.getElementById('icon1').style	= "padding:4px;background-color: white";
					document.getElementById('icon2').style	= "padding:4px;background-color: white";
					document.getElementById('icon3').style	= "padding:4px;background-color: white";
					document.getElementById('icon4').style	= "padding:4px;background-color: white";
					document.getElementById('icon5').style	= "padding:4px;background-color: white";
					document.getElementById('icon6').style	= "padding:4px;background-color: white";
					document.getElementById('icon7').style	= "padding:4px;background-color: white";
					document.getElementById('icon8').style	= "padding:4px;background-color: white";
					document.getElementById('icon9').style	= "padding:4px;background-color: white";
				}
			}