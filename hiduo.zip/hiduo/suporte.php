<?php
// criar conexao e dar include aqui.
include "conexao.php";
include "seguranca.php";
include "mensagem.php";

// Pesuisa do usuário logado
$sql = "SELECT * FROM usuario WHERE username_usuario = '".$_SESSION['username_usuario']."'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array( $result);

// Selecao dos campos

if(isset($_POST['submit'])){
$nome_suporte=$_POST['nome_suporte'];
$email_suporte=$_POST['email_suporte'];
$assunto_suporte=$_POST['assunto_suporte'];
$categoria_suporte=$_POST['categoria_suporte'];
$msg_suporte=$_POST['msg_suporte'];

	if(isset($_POST['nome_suporte']) 
		&& isset($_POST['email_suporte'])  
		&& isset($_POST['assunto_suporte'])  
		&& isset($_POST['categoria_suporte'])  
		&& isset($_POST['msg_suporte']) ){

		// Insercao de dados e envio
    $sqlInsert = "INSERT INTO `suporte` (`id_suporte`, `nome_suporte`, `email_suporte`, `assunto_suporte`, `categoria_suporte`, `msg_suporte`) VALUES (NULL, '$nome_suporte', '$email_suporte', '$assunto_suporte', '$categoria_suporte', '$msg_suporte')";
    $rsInsert = mysqli_query($conn, $sqlInsert);

	if(mysqli_errno($conn)==0){
		$msg = new Mensagem("Mensagem enviada!","Iremos responder assim que possível.","success");
	}
	 else {
		 $msg = new Mensagem("Erro","Algo está errado :( ". mysqli_error($conn),"danger");
	}
	} else {		
		$msg = new Mensagem("Erro","Preencha todos os campos!". mysqli_error($conn),"danger");
	}

}	
?>

<html>
	<head>
		<title>HiDuo! - Suporte</title>
		<meta charset="utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		
		<link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">

		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		
		<link rel="shortcut icon" href="image/hiduo" type="image/x-icon">
		<link href="css/suporte.css" rel="stylesheet">

		<style type="text/css" >
	.msg-erro{ color: red; }
	</style>
 		
	<body>
		<nav>
			<form>
					<ul class="nav nav-pills nav-fill nav-justified">
						<li class="nav-item"><a href="index.php" id="active" class="nav-link"><img src="image/hiduoicon.png" width="80"></a></li>
						<li class="nav-item"><a href="dupla.php" class="nav-link">Procurar Dupla</a></li>
						<li class="nav-item"><a href="rank.php" class="nav-link">Melhores Duplas</a></li>
						<li class="nav-item"><a href="suporte.php" class="nav-link">Suporte</a></li>
						<li class="nav-item"><a href="logout.php" class="nav-link">Sair</a></li>
					</ul>
			</form>
		</nav>
		<div class="col-md-3">
			<aside>
			<form method="post" action="suporte.php" class="form-horizontal">
				<div class="form-group">
					<div class="col-sm-12">
						<input type="text" class="form-control" id="nome" name="nome_suporte" placeholder="Nome" <?php echo 'value='.$row['nome_usuario']; ?>>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-12">
						<input type="email" class="form-control" id="email" name="email_suporte" placeholder="Email" <?php echo 'value='.$row['email_usuario']; ?>>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-12">
						<input type="text" class="form-control" id="assunto" name="assunto_suporte" placeholder="Assunto" autofocus="" onchange="validaAssunto()">
					</div>
					<span class='msg-erro msg-assunto'>				
					</span>
				</div>
				<div class="form-group">
					<div class="col-sm-12">
						<select class="form-control" name="categoria_suporte" id="suporte" onchange="validaSuporte()">
							<option value="Sem opcao" selected disabled>Selecione uma opção de suporte</option>
							<option value= "Suporte">Suporte</option>
							<option value= "Bug">Relatar um bug</option>
							<option value= "Sugestoes">Sugestões</option>							
							<option value= "Elogios">Elogios</option>
							<option value= "Reclamaces">Reclamações</option>
							<option value= "Contato"> Contato com a Cats2</option>
						</select>
						<span class="msg-erro msg-tipo">							
						</span>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-12">
						<textarea class="form-control" rows="4" id="Texto" name="msg_suporte" placeholder="Digite sua mensagem aqui..." maxlength="250">
						</textarea>
						<span class="msg-erro msg-texto">							
						</span>
					</div>
				</div>
				<div class="col-md-6"> 
							<button class="btn btn-primary" type="submit" name="submit" onclick="validaSuporte()"> Enviar Mensagem</button>
					</div>
			</form>
		</aside>
							<?php
		if(isset($msg)) $msg->mostrar();
		?>
				</div>
			
		</div>
		 <div class="container theme-showcase" role="main">
		<div class="col-md-9">
			<div id="conteudo">
			<h3><p class="text-center text-uppercase" style="color: white;" ><strong class="container-fluid text-center">Perguntas mais frequentes</strong></p></h3>
			<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default" id="pergunta">
    <div class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
         Qual é o principal objetivo da plataforma?
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body">
        No mundo dos gamers é muito importante a interação entre eles e o trabalho em equipe. Na maior parte dos jogos, os jogadores são   
      	emparelhados aleatoriamente, e o único suporte que eles têm entre si e dentro da partida. Notamos que há falta de interação e de 
      	uma ferramenta que possa fazer encontrar uma dupla ou até um time para que você possa se comunicar.
        Nossa intenção é trazer uma interação entre jogadores com o mesmo interesse em jogos.
      </div>
    </div>
  </div>
  <div class="panel panel-default" id="pergunta">
    <div class="panel-heading" role="tab" id="headingTwo">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Quais são os jogos que o HiDuo trabalha?
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
      <div class="panel-body">
        <ol>
			<li>League Of Legends</li>
			<li>PlayersUnknows Battlegrounds</li>
			<li>Overwatch</li>
			<!-- São esse os jogos, certo? -->
		</ol>						
      </div>
    </div>
  </div>
  <div class="panel panel-default" id="pergunta">
    <div class="panel-heading" role="tab" id="headingThree">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
			Como acho a minha dupla perfeita?
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
      <div class="panel-body">
         É simples, o HiDuo irá encontrar o parceiro ideal para sua jogatina. Basta apenas seguir os passos:
         <li>1. Entre no site com a sua conta, mas caso você ainda não tenha criado, basta apenas clicar <a href="cadastro.php" target="_blank"> aqui. </a> </li>
         <li> 2. Na tela inicial, escolha um dos jogos para encontrar uma dupla. </li>
         <li> 3. Defina os filtros para encontrar sua dupla. </li>
         <li> 4. Clique em Jogar para começar. </li>

							<!-- Eu sei que não é, apenas add para encher linguiça-->
      </div>
    </div>
  </div	>
</div>
			</div>
			</div>
		</div>	
			<script type="text/javascript" src="js/suporte.js"></script>
	</body>
</html>